Calendar
===

Calendar is a Javascript class that adds accessible and unobtrusive date-pickers to your form elements.

### Features

- Style-able and semantic XHTML
- Future / past calendar restrictions (and more)
- Highly configurable use of inputs and selects
- Multi-calendar support (with padding)
- Variable navigation options
- Multi-lingual and fancy date formatting

More information here: http://www.electricprism.com/aeron/calendar/

If you use Calendar on your website please consider donating!